#!/usr/bin/env bash

npm install gulp gulp-rename gulp-less gulp-minify-css

